
public class Main {
	
	public static void main(String[] args) {
		Matriz a1 = new Matriz();
		
		a1.ImpimirMatriz();
		System.out.println("");
		a1.Soma();
		System.out.println("");
		a1.subtracao();
		System.out.println("");
		a1.divide();
		System.out.println("");
		a1.multiplica();
		System.out.println("");
		a1.determinantea();
		System.out.println("");
		a1.determinanteb();
		
	}

}
